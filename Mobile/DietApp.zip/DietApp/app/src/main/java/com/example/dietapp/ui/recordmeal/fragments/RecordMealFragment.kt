package com.example.dietapp.ui.recordmeal.fragments

import androidx.fragment.app.Fragment
import com.example.dietapp.ui.recordmeal.RecordMealAdapter

abstract class RecordMealFragment: Fragment(){
    var adapter: RecordMealAdapter? = null
}