package com.example.dietapp.ui.createmeal

import com.example.dietapp.api.MealsService
import com.example.dietapp.di.scopes.ActivityScope
import com.example.dietapp.models.MealDTO
import com.example.dietapp.models.Nutrients
import com.example.dietapp.ui.base.BasePresenter
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import javax.inject.Inject

@ActivityScope
class CreateMealPresenter @Inject constructor(private val mealsService: MealsService) :
    BasePresenter<CreateMealView>() {

    fun addMeal(name: String, nutrients: Nutrients) {
        mealsService.createMeal(MealDTO(name, nutrients)).enqueue(object : Callback<List<MealDTO>> {
            override fun onFailure(call: Call<List<MealDTO>>, t: Throwable) {
                mvpView?.showConnectionError()
            }

            override fun onResponse(call: Call<List<MealDTO>>, response: Response<List<MealDTO>>) {
                if (!response.isSuccessful) {

                }
            }

        })
    }
}