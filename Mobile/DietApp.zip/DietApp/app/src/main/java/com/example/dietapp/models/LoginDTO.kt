package com.example.dietapp.models

data class LoginDTO(val nickname: String, val password: String)