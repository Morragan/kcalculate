package com.example.dietapp.ui.main

interface MainView {
    fun showConnectionError()
    fun login()
    fun logout()
}