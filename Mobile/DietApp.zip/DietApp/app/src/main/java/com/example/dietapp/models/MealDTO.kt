package com.example.dietapp.models

data class MealDTO(val name: String, val nutrients: Nutrients)