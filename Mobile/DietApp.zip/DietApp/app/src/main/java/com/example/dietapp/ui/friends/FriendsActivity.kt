package com.example.dietapp.ui.friends

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.dietapp.R

class FriendsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_friends)
    }
}
