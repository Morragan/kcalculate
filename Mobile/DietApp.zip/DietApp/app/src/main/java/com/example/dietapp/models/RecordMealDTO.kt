package com.example.dietapp.models

data class RecordMealDTO(val name: String, val nutrients: Nutrients, val weightGram: Int)